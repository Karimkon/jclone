<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name') }} - Buy & Sell Everything</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'jakarta': ['Plus Jakarta Sans', 'sans-serif'],
                    },
                    colors: {
                        primary: '#4f46e5',
                        'primary-dark': '#4338ca',
                        secondary: '#10b981',
                        accent: '#f59e0b',
                        dark: '#1e1e2e',
                        'dark-light': '#2a2a3e',
                    }
                }
            }
        }
    </script>
    
    <style>
        * {
            font-family: 'Plus Jakarta Sans', sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        
        /* Mega Menu Styles */
        .mega-menu {
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: all 0.3s ease;
        }
        
        .category-trigger:hover .mega-menu,
        .mega-menu:hover {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .category-item:hover .subcategory-panel {
            display: block;
        }
        
        .subcategory-panel {
            display: none;
        }
        
        /* Product Card Hover */
        .product-card {
            transition: all 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        
        .product-card:hover .product-actions {
            opacity: 1;
            transform: translateY(0);
        }
        
        .product-actions {
            opacity: 0;
            transform: translateY(10px);
            transition: all 0.3s ease;
        }
        
        /* Category Sidebar Hover */
        .cat-sidebar-item {
            position: relative;
        }
        
        .cat-sidebar-item:hover {
            background: linear-gradient(90deg, #4f46e5 0%, #6366f1 100%);
            color: white;
        }
        
        .cat-sidebar-item:hover .cat-arrow {
            color: white;
        }
        
        .cat-submenu {
            display: none;
            position: absolute;
            left: 100%;
            top: 0;
            min-width: 600px;
            background: white;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            border-radius: 0 8px 8px 0;
            z-index: 100;
        }
        
        .cat-sidebar-item:hover .cat-submenu {
            display: block;
        }
        
        /* Banner Slider */
        .banner-slide {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #4f46e5 100%);
        }
        
        /* Flash Sale Timer */
        .timer-box {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #4f46e5;
            border-radius: 4px;
        }
        
        /* Badge Pulse */
        @keyframes pulse-badge {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        .badge-pulse {
            animation: pulse-badge 2s infinite;
        }
        
        /* Skeleton Loading */
        .skeleton {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: skeleton-loading 1.5s infinite;
        }
        
        @keyframes skeleton-loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        
        /* Quick View Modal */
        .modal-backdrop {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(4px);
        }
        
        /* Price Strike */
        .price-old {
            position: relative;
        }
        
        .price-old::after {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: #ef4444;
            transform: rotate(-10deg);
        }
        
        /* Smooth Scroll */
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Top Bar -->
    <div class="bg-dark text-white text-sm py-2">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <span class="flex items-center">
                        <i class="fas fa-shield-alt text-secondary mr-2"></i>
                        100% Secure Escrow Protection
                    </span>
                    <span class="hidden md:flex items-center">
                        <i class="fas fa-truck text-accent mr-2"></i>
                        Free Shipping on Orders $50+
                    </span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="#" class="hover:text-secondary transition">Sell on {{ config('app.name') }}</a>
                    <span class="text-gray-500">|</span>
                    <a href="#" class="hover:text-secondary transition">Help</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Header -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between py-4">
                <!-- Logo -->
                <a href="{{ route('welcome') }}" class="flex items-center space-x-2">
                    <div class="w-10 h-10 bg-gradient-to-br from-primary to-purple-600 rounded-xl flex items-center justify-center">
                        <i class="fas fa-store text-white text-lg"></i>
                    </div>
                    <span class="text-2xl font-bold text-dark">{{ config('app.name') }}</span>
                </a>
                
                <!-- Search Bar -->
                <div class="hidden md:flex flex-1 max-w-2xl mx-8">
                    <div class="relative w-full">
                        <input type="text" 
                               placeholder="Search for products, brands and categories..." 
                               class="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-primary focus:outline-none transition">
                        <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <button class="absolute right-2 top-1/2 -translate-y-1/2 bg-primary text-white px-6 py-2 rounded-lg font-semibold hover:bg-primary-dark transition">
                            Search
                        </button>
                    </div>
                </div>
                
                <!-- User Actions -->
                <div class="flex items-center space-x-6">
                    @auth
                        <a href="{{ route('buyer.dashboard') }}" class="hidden md:flex flex-col items-center text-gray-600 hover:text-primary transition">
                            <i class="fas fa-user text-xl"></i>
                            <span class="text-xs mt-1">Account</span>
                        </a>
                    @else
                        <a href="{{ route('login') }}" class="hidden md:flex flex-col items-center text-gray-600 hover:text-primary transition">
                            <i class="fas fa-user text-xl"></i>
                            <span class="text-xs mt-1">Login</span>
                        </a>
                    @endauth
                    
                    <a href="{{ route('buyer.wishlist.index') }}" class="relative flex flex-col items-center text-gray-600 hover:text-primary transition">
                        <i class="fas fa-heart text-xl"></i>
                        <span class="text-xs mt-1 hidden md:block">Wishlist</span>
                        <span class="wishlist-count absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center hidden">0</span>
                    </a>
                    
                    <a href="{{ route('buyer.cart.index') }}" class="relative flex flex-col items-center text-gray-600 hover:text-primary transition">
                        <i class="fas fa-shopping-cart text-xl"></i>
                        <span class="text-xs mt-1 hidden md:block">Cart</span>
                        <span class="cart-count absolute -top-1 -right-1 bg-primary text-white text-xs w-5 h-5 rounded-full flex items-center justify-center hidden">0</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Navigation Bar -->
        <div class="bg-primary">
            <div class="container mx-auto px-4">
                <div class="flex items-center">
                    <!-- Categories Mega Menu Trigger -->
                    <div class="category-trigger relative">
                        <button class="flex items-center space-x-2 bg-primary-dark text-white px-6 py-3 font-semibold">
                            <i class="fas fa-bars"></i>
                            <span>All Categories</span>
                            <i class="fas fa-chevron-down text-sm"></i>
                        </button>
                        
                        <!-- Mega Menu Dropdown -->
                        <div class="mega-menu absolute top-full left-0 w-64 bg-white shadow-2xl rounded-b-lg z-50">
                            @foreach($categories as $category)
                            <div class="cat-sidebar-item">
                                <a href="{{ route('marketplace.index', ['category' => $category->id]) }}" 
                                   class="flex items-center justify-between px-4 py-3 text-gray-700 hover:text-white transition">
                                    <span class="flex items-center">
                                        <i class="fas fa-{{ $category->icon ?? 'tag' }} w-6 text-primary group-hover:text-white"></i>
                                        <span class="ml-3">{{ $category->name }}</span>
                                    </span>
                                    @if($category->children && $category->children->count() > 0)
                                    <i class="fas fa-chevron-right text-xs cat-arrow text-gray-400"></i>
                                    @endif
                                </a>
                                
                                @if($category->children && $category->children->count() > 0)
                                <!-- Subcategory Panel -->
                                <div class="cat-submenu p-6">
                                    <div class="grid grid-cols-3 gap-6">
                                        @foreach($category->children->take(9) as $child)
                                        <div>
                                            <a href="{{ route('marketplace.index', ['category' => $child->id]) }}" 
                                               class="font-semibold text-dark hover:text-primary mb-2 block">
                                                {{ $child->name }}
                                            </a>
                                            @if($child->children && $child->children->count() > 0)
                                            <ul class="space-y-1">
                                                @foreach($child->children->take(5) as $grandchild)
                                                <li>
                                                    <a href="{{ route('marketplace.index', ['category' => $grandchild->id]) }}" 
                                                       class="text-sm text-gray-500 hover:text-primary">
                                                        {{ $grandchild->name }}
                                                    </a>
                                                </li>
                                                @endforeach
                                            </ul>
                                            @endif
                                        </div>
                                        @endforeach
                                    </div>
                                    
                                    <!-- Featured Products in Category -->
                                    @if($category->listings && $category->listings->count() > 0)
                                    <div class="mt-6 pt-6 border-t">
                                        <h4 class="font-semibold text-dark mb-4">Popular in {{ $category->name }}</h4>
                                        <div class="grid grid-cols-4 gap-4">
                                            @foreach($category->listings->take(4) as $product)
                                            <a href="{{ route('marketplace.show', $product) }}" class="group">
                                                <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-2">
                                                    @if($product->images->first())
                                                    <img src="{{ asset('storage/' . $product->images->first()->path) }}" 
                                                         alt="{{ $product->title }}"
                                                         class="w-full h-full object-cover group-hover:scale-105 transition">
                                                    @endif
                                                </div>
                                                <p class="text-xs text-gray-600 line-clamp-1">{{ $product->title }}</p>
                                                <p class="text-sm font-bold text-primary">${{ number_format($product->price, 2) }}</p>
                                            </a>
                                            @endforeach
                                        </div>
                                    </div>
                                    @endif
                                </div>
                                @endif
                            </div>
                            @endforeach
                        </div>
                    </div>
                    
                    <!-- Quick Links -->
                    <nav class="hidden lg:flex items-center space-x-1 ml-4">
                        <a href="{{ route('marketplace.index') }}" class="text-white px-4 py-3 hover:bg-white/10 transition rounded">
                            <i class="fas fa-fire text-accent mr-2"></i>Deals
                        </a>
                        <a href="{{ route('marketplace.index', ['origin' => 'imported']) }}" class="text-white px-4 py-3 hover:bg-white/10 transition rounded">
                            <i class="fas fa-plane mr-2"></i>Imported
                        </a>
                        <a href="{{ route('marketplace.index', ['origin' => 'local']) }}" class="text-white px-4 py-3 hover:bg-white/10 transition rounded">
                            <i class="fas fa-home mr-2"></i>Local
                        </a>
                        <a href="{{ route('vendor.onboard.create') }}" class="text-white px-4 py-3 hover:bg-white/10 transition rounded">
                            <i class="fas fa-store mr-2"></i>Sell
                        </a>
                        <a href="#" class="text-white px-4 py-3 hover:bg-white/10 transition rounded">
                            <i class="fas fa-headset mr-2"></i>Help
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-6">
        <div class="flex gap-6">
            <!-- Left Sidebar - Categories (Desktop) -->
            <aside class="hidden lg:block w-64 flex-shrink-0">
                <div class="bg-white rounded-xl shadow-sm overflow-hidden sticky top-32">
                    <div class="bg-gradient-to-r from-primary to-purple-600 text-white px-4 py-3 font-semibold">
                        <i class="fas fa-th-large mr-2"></i>Browse Categories
                    </div>
                    <div class="divide-y">
                        @foreach($categories->take(12) as $category)
                        <div class="cat-sidebar-item">
                            <a href="{{ route('marketplace.index', ['category' => $category->id]) }}" 
                               class="flex items-center justify-between px-4 py-3 text-gray-700 transition">
                                <span class="flex items-center">
                                    <i class="fas fa-{{ $category->icon ?? 'tag' }} w-5 text-gray-400"></i>
                                    <span class="ml-3 text-sm">{{ $category->name }}</span>
                                </span>
                                @if($category->children && $category->children->count() > 0)
                                <i class="fas fa-chevron-right text-xs cat-arrow text-gray-400"></i>
                                @endif
                            </a>
                            
                            @if($category->children && $category->children->count() > 0)
                            <div class="cat-submenu p-4">
                                <h4 class="font-bold text-dark mb-3 pb-2 border-b">{{ $category->name }}</h4>
                                <div class="grid grid-cols-2 gap-4">
                                    @foreach($category->children as $child)
                                    <div>
                                        <a href="{{ route('marketplace.index', ['category' => $child->id]) }}" 
                                           class="font-medium text-dark hover:text-primary text-sm">
                                            {{ $child->name }}
                                        </a>
                                        @if($child->children && $child->children->count() > 0)
                                        <ul class="mt-2 space-y-1">
                                            @foreach($child->children->take(4) as $grandchild)
                                            <li>
                                                <a href="{{ route('marketplace.index', ['category' => $grandchild->id]) }}" 
                                                   class="text-xs text-gray-500 hover:text-primary">
                                                    {{ $grandchild->name }}
                                                </a>
                                            </li>
                                            @endforeach
                                        </ul>
                                        @endif
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            </aside>
            
            <!-- Main Content Area -->
            <div class="flex-1 min-w-0">
                <!-- Hero Banner Slider -->
                <section class="mb-6">
                    <div class="swiper hero-swiper rounded-2xl overflow-hidden shadow-lg">
                        <div class="swiper-wrapper">
                            <!-- Slide 1 - Main Value Prop -->
                            <div class="swiper-slide">
                                <div class="banner-slide relative h-72 md:h-80 p-8 md:p-12">
                                    <div class="relative z-10 h-full flex flex-col justify-center">
                                        <span class="inline-block bg-white/20 text-white px-3 py-1 rounded-full text-sm mb-4 w-fit">
                                            🛡️ Escrow Protected
                                        </span>
                                        <h1 class="text-3xl md:text-5xl font-bold text-white mb-4 leading-tight">
                                            Buy Local & Imported<br>
                                            <span class="text-accent">With Confidence</span>
                                        </h1>
                                        <p class="text-white/80 text-lg mb-6 max-w-lg">
                                            Secure marketplace with integrated logistics and customs clearance
                                        </p>
                                        <div class="flex gap-4">
                                            <a href="{{ route('marketplace.index') }}" class="bg-white text-primary px-6 py-3 rounded-lg font-bold hover:bg-gray-100 transition">
                                                Shop Now
                                            </a>
                                            <a href="{{ route('vendor.onboard.create') }}" class="border-2 border-white text-white px-6 py-3 rounded-lg font-bold hover:bg-white hover:text-primary transition">
                                                Start Selling
                                            </a>
                                        </div>
                                    </div>
                                    <!-- Decorative Elements -->
                                    <div class="absolute right-0 top-0 w-1/2 h-full opacity-20">
                                        <svg viewBox="0 0 200 200" class="w-full h-full">
                                            <circle cx="100" cy="100" r="80" fill="white" fill-opacity="0.1"/>
                                            <circle cx="150" cy="50" r="40" fill="white" fill-opacity="0.1"/>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Slide 2 - Flash Sale -->
                            <div class="swiper-slide">
                                <div class="relative h-72 md:h-80 p-8 md:p-12 bg-gradient-to-r from-red-500 to-orange-500">
                                    <div class="relative z-10 h-full flex flex-col justify-center">
                                        <span class="inline-block bg-white text-red-500 px-3 py-1 rounded-full text-sm font-bold mb-4 w-fit badge-pulse">
                                            🔥 FLASH SALE
                                        </span>
                                        <h2 class="text-3xl md:text-5xl font-bold text-white mb-4">
                                            Up to 70% OFF
                                        </h2>
                                        <p class="text-white/90 text-lg mb-6">
                                            Limited time offers on top products
                                        </p>
                                        <div class="flex items-center gap-3 mb-6">
                                            <span class="text-white font-medium">Ends in:</span>
                                            <div class="flex gap-2">
                                                <div class="timer-box px-3 py-2 rounded-lg text-white">
                                                    <span class="text-2xl font-bold" id="hours">12</span>
                                                    <span class="text-xs block">HRS</span>
                                                </div>
                                                <div class="timer-box px-3 py-2 rounded-lg text-white">
                                                    <span class="text-2xl font-bold" id="minutes">45</span>
                                                    <span class="text-xs block">MIN</span>
                                                </div>
                                                <div class="timer-box px-3 py-2 rounded-lg text-white">
                                                    <span class="text-2xl font-bold" id="seconds">30</span>
                                                    <span class="text-xs block">SEC</span>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="{{ route('marketplace.index') }}" class="bg-white text-red-500 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition w-fit">
                                            Shop Flash Sale
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Slide 3 - Import Service -->
                            <div class="swiper-slide">
                                <div class="relative h-72 md:h-80 p-8 md:p-12 bg-gradient-to-r from-secondary to-teal-500">
                                    <div class="relative z-10 h-full flex flex-col justify-center">
                                        <span class="inline-block bg-white/20 text-white px-3 py-1 rounded-full text-sm mb-4 w-fit">
                                            ✈️ Import Services
                                        </span>
                                        <h2 class="text-3xl md:text-5xl font-bold text-white mb-4">
                                            Import From China<br>
                                            <span class="text-yellow-300">Hassle-Free</span>
                                        </h2>
                                        <p class="text-white/90 text-lg mb-6 max-w-lg">
                                            Complete customs clearance & doorstep delivery
                                        </p>
                                        <a href="#import-calculator" class="bg-white text-secondary px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition w-fit">
                                            Calculate Import Cost
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </section>
                
                <!-- Quick Category Pills -->
                <section class="mb-6 overflow-x-auto pb-2">
                    <div class="flex gap-3 min-w-max">
                        @foreach($categories->take(10) as $category)
                        <a href="{{ route('marketplace.index', ['category' => $category->id]) }}" 
                           class="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm hover:shadow-md hover:bg-primary hover:text-white transition group">
                            <i class="fas fa-{{ $category->icon ?? 'tag' }} text-primary group-hover:text-white"></i>
                            <span class="text-sm font-medium">{{ $category->name }}</span>
                        </a>
                        @endforeach
                    </div>
                </section>
                
                <!-- Featured Products Section -->
                @if(isset($featuredProducts) && $featuredProducts->count() > 0)
                <section class="mb-8">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-1 h-8 bg-primary rounded-full"></div>
                            <h2 class="text-xl font-bold text-dark">⭐ Featured Products</h2>
                        </div>
                        <a href="{{ route('marketplace.index') }}" class="text-primary font-medium hover:underline flex items-center gap-1">
                            See All <i class="fas fa-arrow-right text-sm"></i>
                        </a>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                        @foreach($featuredProducts->take(10) as $product)
                        @include('partials.product-card', ['product' => $product])
                        @endforeach
                    </div>
                </section>
                @endif
                
                <!-- Flash Deals Section -->
                <section class="mb-8">
                    <div class="bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center gap-4">
                                <h2 class="text-xl font-bold text-white flex items-center gap-2">
                                    <i class="fas fa-bolt text-yellow-300"></i>
                                    Flash Deals
                                </h2>
                                <div class="flex items-center gap-2 text-white">
                                    <span class="text-sm">Ends in:</span>
                                    <div class="flex gap-1">
                                        <span class="bg-white/20 px-2 py-1 rounded text-sm font-bold">12</span>:
                                        <span class="bg-white/20 px-2 py-1 rounded text-sm font-bold">45</span>:
                                        <span class="bg-white/20 px-2 py-1 rounded text-sm font-bold">30</span>
                                    </div>
                                </div>
                            </div>
                            <a href="{{ route('marketplace.index') }}" class="text-white font-medium hover:underline flex items-center gap-1">
                                See All <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                        
                        <div class="swiper flash-deals-swiper">
                            <div class="swiper-wrapper">
                                @foreach($newArrivals->take(10) as $product)
                                <div class="swiper-slide">
                                    <div class="bg-white rounded-xl p-3 product-card">
                                        <div class="relative aspect-square mb-3 overflow-hidden rounded-lg bg-gray-100">
                                            <a href="{{ route('marketplace.show', $product) }}">
                                                @if($product->images->first())
                                                <img src="{{ asset('storage/' . $product->images->first()->path) }}" 
                                                     alt="{{ $product->title }}"
                                                     class="w-full h-full object-cover hover:scale-105 transition duration-300">
                                                @else
                                                <div class="w-full h-full flex items-center justify-center">
                                                    <i class="fas fa-image text-gray-300 text-3xl"></i>
                                                </div>
                                                @endif
                                            </a>
                                            <span class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                                                -{{ rand(20, 50) }}%
                                            </span>
                                        </div>
                                        <a href="{{ route('marketplace.show', $product) }}">
                                            <h3 class="text-sm text-gray-700 line-clamp-2 mb-2 hover:text-primary">
                                                {{ $product->title }}
                                            </h3>
                                        </a>
                                        <div class="flex items-center gap-2">
                                            <span class="text-lg font-bold text-primary">${{ number_format($product->price, 2) }}</span>
                                            <span class="text-xs text-gray-400 line-through">${{ number_format($product->price * 1.3, 2) }}</span>
                                        </div>
                                        <div class="mt-2 bg-gray-200 rounded-full h-2 overflow-hidden">
                                            <div class="bg-red-500 h-full rounded-full" style="width: {{ rand(30, 80) }}%"></div>
                                        </div>
                                        <p class="text-xs text-gray-500 mt-1">{{ rand(10, 50) }} sold</p>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </section>
                
                <!-- Categories Grid -->
                <section class="mb-8">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-1 h-8 bg-secondary rounded-full"></div>
                            <h2 class="text-xl font-bold text-dark">🏷️ Shop by Category</h2>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                        @php
                            $categoryIcons = ['laptop', 'tshirt', 'couch', 'blender', 'futbol', 'baby-carriage', 'car', 'gem', 'book', 'pills', 'paint-brush', 'gamepad'];
                            $categoryColors = ['bg-blue-50 text-blue-600', 'bg-pink-50 text-pink-600', 'bg-amber-50 text-amber-600', 'bg-green-50 text-green-600', 'bg-purple-50 text-purple-600', 'bg-rose-50 text-rose-600'];
                        @endphp
                        @foreach($categories->take(12) as $index => $category)
                        <a href="{{ route('marketplace.index', ['category' => $category->id]) }}" 
                           class="bg-white rounded-xl p-4 text-center hover:shadow-lg transition group">
                            <div class="w-14 h-14 mx-auto mb-3 rounded-xl {{ $categoryColors[$index % count($categoryColors)] }} flex items-center justify-center group-hover:scale-110 transition">
                                <i class="fas fa-{{ $category->icon ?? $categoryIcons[$index % count($categoryIcons)] }} text-2xl"></i>
                            </div>
                            <h3 class="text-sm font-medium text-gray-700 group-hover:text-primary">{{ $category->name }}</h3>
                            <p class="text-xs text-gray-400 mt-1">{{ $category->listings_count ?? rand(50, 500) }}+ items</p>
                        </a>
                        @endforeach
                    </div>
                </section>
                
                <!-- Trending Products -->
                <section class="mb-8">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-1 h-8 bg-accent rounded-full"></div>
                            <h2 class="text-xl font-bold text-dark">🔥 Trending Now</h2>
                        </div>
                        <a href="{{ route('marketplace.index') }}" class="text-primary font-medium hover:underline flex items-center gap-1">
                            See All <i class="fas fa-arrow-right text-sm"></i>
                        </a>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                        @foreach($newArrivals as $product)
                        <div class="product-card bg-white rounded-xl overflow-hidden shadow-sm">
                            <div class="relative aspect-square overflow-hidden bg-gray-100">
                                <a href="{{ route('marketplace.show', $product) }}">
                                    @if($product->images->first())
                                    <img src="{{ asset('storage/' . $product->images->first()->path) }}" 
                                         alt="{{ $product->title }}"
                                         class="w-full h-full object-cover hover:scale-105 transition duration-300">
                                    @else
                                    <div class="w-full h-full flex items-center justify-center">
                                        <i class="fas fa-image text-gray-300 text-4xl"></i>
                                    </div>
                                    @endif
                                </a>
                                
                                <!-- Badges -->
                                <div class="absolute top-2 left-2 flex flex-col gap-1">
                                    @if($product->origin == 'imported')
                                    <span class="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                                        <i class="fas fa-plane mr-1"></i>Imported
                                    </span>
                                    @else
                                    <span class="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                                        <i class="fas fa-home mr-1"></i>Local
                                    </span>
                                    @endif
                                </div>
                                
                                <!-- Quick Actions -->
                                <div class="product-actions absolute top-2 right-2 flex flex-col gap-2">
                                    <button data-quick-wishlist data-listing-id="{{ $product->id }}"
                                            class="w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-red-50 transition">
                                        <i class="far fa-heart text-gray-600 hover:text-red-500"></i>
                                    </button>
                                    <button class="w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-blue-50 transition"
                                            onclick="quickView({{ $product->id }})">
                                        <i class="fas fa-eye text-gray-600 hover:text-primary"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="p-3">
                                <p class="text-xs text-gray-400 mb-1">{{ $product->category->name ?? 'Uncategorized' }}</p>
                                <a href="{{ route('marketplace.show', $product) }}">
                                    <h3 class="text-sm font-medium text-gray-700 line-clamp-2 mb-2 hover:text-primary transition">
                                        {{ $product->title }}
                                    </h3>
                                </a>
                                
                                <div class="flex items-center gap-1 mb-2">
                                    <div class="flex text-yellow-400">
                                        @for($i = 0; $i < 5; $i++)
                                        <i class="fas fa-star text-xs"></i>
                                        @endfor
                                    </div>
                                    <span class="text-xs text-gray-400">({{ rand(10, 200) }})</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <span class="text-lg font-bold text-primary">${{ number_format($product->price, 2) }}</span>
                                    @if($product->stock > 0)
                                    <button data-quick-cart data-listing-id="{{ $product->id }}"
                                            class="w-9 h-9 bg-primary text-white rounded-lg flex items-center justify-center hover:bg-primary-dark transition">
                                        <i class="fas fa-shopping-cart text-sm"></i>
                                    </button>
                                    @else
                                    <span class="text-xs text-red-500">Out of Stock</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </section>
                
                <!-- Recently Added -->
                @if(isset($recentProducts) && $recentProducts->count() > 0)
                <section class="mb-8">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-1 h-8 bg-purple-500 rounded-full"></div>
                            <h2 class="text-xl font-bold text-dark">🆕 Just Arrived</h2>
                        </div>
                        <a href="{{ route('marketplace.index', ['sort' => 'newest']) }}" class="text-primary font-medium hover:underline flex items-center gap-1">
                            See All <i class="fas fa-arrow-right text-sm"></i>
                        </a>
                    </div>
                    
                    <div class="swiper new-arrivals-swiper">
                        <div class="swiper-wrapper">
                            @foreach($recentProducts as $product)
                            <div class="swiper-slide">
                                <div class="product-card bg-white rounded-xl overflow-hidden shadow-sm">
                                    <div class="relative aspect-square overflow-hidden bg-gray-100">
                                        <a href="{{ route('marketplace.show', $product) }}">
                                            @if($product->images->first())
                                            <img src="{{ asset('storage/' . $product->images->first()->path) }}" 
                                                 alt="{{ $product->title }}"
                                                 class="w-full h-full object-cover">
                                            @endif
                                        </a>
                                        <span class="absolute top-2 left-2 bg-purple-500 text-white text-xs px-2 py-1 rounded-full">
                                            NEW
                                        </span>
                                    </div>
                                    <div class="p-3">
                                        <h3 class="text-sm text-gray-700 line-clamp-2 mb-2">{{ $product->title }}</h3>
                                        <span class="text-lg font-bold text-primary">${{ number_format($product->price, 2) }}</span>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    </div>
                </section>
                @endif
                
                <!-- Import Calculator Section -->
                <section id="import-calculator" class="mb-8">
                    <div class="bg-gradient-to-br from-dark to-dark-light rounded-2xl p-6 md:p-8 text-white">
                        <div class="grid md:grid-cols-2 gap-8">
                            <div>
                                <h2 class="text-2xl font-bold mb-2">📊 Import Cost Calculator</h2>
                                <p class="text-gray-300 mb-6">Calculate customs duties, shipping & total landed cost</p>
                                
                                <div class="space-y-4">
                                    <div>
                                        <label class="text-sm text-gray-300 mb-1 block">Product Value (USD)</label>
                                        <input type="number" id="productValue" placeholder="e.g., 1000"
                                               class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-primary focus:outline-none">
                                    </div>
                                    <div>
                                        <label class="text-sm text-gray-300 mb-1 block">Shipping Cost (USD)</label>
                                        <input type="number" id="shippingCost" placeholder="e.g., 200"
                                               class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-primary focus:outline-none">
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <label class="text-sm text-gray-300 mb-1 block">Duty Rate (%)</label>
                                            <input type="number" id="dutyRate" value="10"
                                                   class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:border-primary focus:outline-none">
                                        </div>
                                        <div>
                                            <label class="text-sm text-gray-300 mb-1 block">VAT Rate (%)</label>
                                            <input type="number" id="vatRate" value="18"
                                                   class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:border-primary focus:outline-none">
                                        </div>
                                    </div>
                                    <button onclick="calculateImportCost()" 
                                            class="w-full bg-gradient-to-r from-primary to-purple-600 py-4 rounded-lg font-bold hover:opacity-90 transition">
                                        <i class="fas fa-calculator mr-2"></i>Calculate Total Cost
                                    </button>
                                </div>
                            </div>
                            
                            <div>
                                <h3 class="text-lg font-bold mb-4">Cost Breakdown</h3>
                                <div class="bg-white/5 rounded-xl p-4 space-y-3">
                                    <div class="flex justify-between py-2 border-b border-white/10">
                                        <span class="text-gray-300">Product Value</span>
                                        <span id="resultProduct" class="font-bold">$0.00</span>
                                    </div>
                                    <div class="flex justify-between py-2 border-b border-white/10">
                                        <span class="text-gray-300">Shipping</span>
                                        <span id="resultShipping" class="font-bold">$0.00</span>
                                    </div>
                                    <div class="flex justify-between py-2 border-b border-white/10">
                                        <span class="text-gray-300">Import Duty</span>
                                        <span id="resultDuty" class="font-bold">$0.00</span>
                                    </div>
                                    <div class="flex justify-between py-2 border-b border-white/10">
                                        <span class="text-gray-300">VAT</span>
                                        <span id="resultVat" class="font-bold">$0.00</span>
                                    </div>
                                    <div class="flex justify-between py-3 bg-primary/20 rounded-lg px-3 mt-4">
                                        <span class="font-bold">Total Landed Cost</span>
                                        <span id="resultTotal" class="text-2xl font-bold text-accent">$0.00</span>
                                    </div>
                                </div>
                                
                                <div class="mt-4 p-4 bg-blue-500/20 rounded-lg">
                                    <p class="text-sm text-blue-200">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        This is an estimate. Actual costs may vary based on product classification.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                
                <!-- Trust Badges -->
                <section class="mb-8">
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm">
                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-shield-alt text-green-600 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-dark">Secure Escrow</h4>
                                <p class="text-xs text-gray-500">Money protected until delivery</p>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm">
                            <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-truck text-blue-600 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-dark">Fast Delivery</h4>
                                <p class="text-xs text-gray-500">Nationwide shipping</p>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm">
                            <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-headset text-purple-600 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-dark">24/7 Support</h4>
                                <p class="text-xs text-gray-500">Always here to help</p>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm">
                            <div class="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-undo text-amber-600 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-dark">Easy Returns</h4>
                                <p class="text-xs text-gray-500">30-day return policy</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Right Sidebar - Ads/Promotions (Desktop) -->
            <aside class="hidden xl:block w-56 flex-shrink-0">
                <div class="sticky top-32 space-y-4">
                    <!-- Promo Banner -->
                    <div class="bg-gradient-to-br from-primary to-purple-600 rounded-xl p-4 text-white text-center">
                        <i class="fas fa-gift text-3xl mb-2"></i>
                        <h4 class="font-bold mb-1">New User?</h4>
                        <p class="text-sm text-white/80 mb-3">Get 10% off your first order</p>
                        <a href="{{ route('register') }}" class="block bg-white text-primary py-2 rounded-lg font-semibold text-sm hover:bg-gray-100 transition">
                            Sign Up Now
                        </a>
                    </div>
                    
                    <!-- App Download -->
                    <div class="bg-white rounded-xl p-4 shadow-sm">
                        <h4 class="font-bold text-dark mb-3 text-sm">Download Our App</h4>
                        <div class="space-y-2">
                            <a href="#" class="flex items-center gap-2 bg-dark text-white px-3 py-2 rounded-lg text-sm hover:bg-gray-800 transition">
                                <i class="fab fa-apple text-lg"></i>
                                <div class="text-left">
                                    <div class="text-xs text-gray-400">Download on</div>
                                    <div class="font-medium">App Store</div>
                                </div>
                            </a>
                            <a href="#" class="flex items-center gap-2 bg-dark text-white px-3 py-2 rounded-lg text-sm hover:bg-gray-800 transition">
                                <i class="fab fa-google-play text-lg"></i>
                                <div class="text-left">
                                    <div class="text-xs text-gray-400">Get it on</div>
                                    <div class="font-medium">Google Play</div>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    <!-- Top Selling -->
                    <div class="bg-white rounded-xl p-4 shadow-sm">
                        <h4 class="font-bold text-dark mb-3 text-sm">🏆 Top Selling</h4>
                        <div class="space-y-3">
                            @foreach($newArrivals->take(3) as $index => $product)
                            <a href="{{ route('marketplace.show', $product) }}" class="flex items-center gap-3 group">
                                <span class="w-6 h-6 bg-{{ $index == 0 ? 'amber' : ($index == 1 ? 'gray' : 'orange') }}-100 text-{{ $index == 0 ? 'amber' : ($index == 1 ? 'gray' : 'orange') }}-600 rounded-full flex items-center justify-center text-xs font-bold">
                                    {{ $index + 1 }}
                                </span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-700 line-clamp-1 group-hover:text-primary">{{ $product->title }}</p>
                                    <p class="text-sm font-bold text-primary">${{ number_format($product->price, 2) }}</p>
                                </div>
                            </a>
                            @endforeach
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white pt-12 pb-6">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-8">
                <!-- About -->
                <div class="col-span-2 md:col-span-1 lg:col-span-2">
                    <div class="flex items-center gap-2 mb-4">
                        <div class="w-10 h-10 bg-gradient-to-br from-primary to-purple-600 rounded-xl flex items-center justify-center">
                            <i class="fas fa-store text-white text-lg"></i>
                        </div>
                        <span class="text-xl font-bold">{{ config('app.name') }}</span>
                    </div>
                    <p class="text-gray-400 text-sm mb-4">
                        Secure marketplace for local and imported goods with integrated logistics and escrow protection.
                    </p>
                    <div class="flex gap-3">
                        <a href="#" class="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-primary transition">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-primary transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-primary transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-primary transition">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h5 class="font-bold mb-4">Quick Links</h5>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ route('marketplace.index') }}" class="text-gray-400 hover:text-white transition">Marketplace</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Flash Deals</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">New Arrivals</a></li>
                        <li><a href="{{ route('vendor.onboard.create') }}" class="text-gray-400 hover:text-white transition">Sell on {{ config('app.name') }}</a></li>
                    </ul>
                </div>
                
                <!-- Support -->
                <div>
                    <h5 class="font-bold mb-4">Support</h5>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Help Center</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Contact Us</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Shipping Info</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition">Returns</a></li>
                    </ul>
                </div>
                
                <!-- Newsletter -->
                <div>
                    <h5 class="font-bold mb-4">Newsletter</h5>
                    <p class="text-gray-400 text-sm mb-3">Get updates on deals & offers</p>
                    <div class="flex">
                        <input type="email" placeholder="Your email" 
                               class="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-l-lg text-sm focus:outline-none focus:border-primary">
                        <button class="bg-primary px-4 py-2 rounded-r-lg hover:bg-primary-dark transition">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Payment Methods -->
            <div class="border-t border-white/10 pt-6">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <p class="text-gray-400 text-sm">© {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
                    <div class="flex items-center gap-3">
                        <span class="text-gray-400 text-sm">We accept:</span>
                        <div class="flex gap-2">
                            <div class="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                                <i class="fab fa-cc-visa text-lg"></i>
                            </div>
                            <div class="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                                <i class="fab fa-cc-mastercard text-lg"></i>
                            </div>
                            <div class="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                                <i class="fab fa-cc-paypal text-lg"></i>
                            </div>
                            <div class="w-10 h-6 bg-white/10 rounded flex items-center justify-center">
                                <i class="fas fa-mobile-alt text-sm"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Auth Modal -->
    <div id="authModal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="modal-backdrop absolute inset-0" onclick="closeAuthModal()"></div>
        <div class="bg-white rounded-2xl max-w-md w-full p-8 relative z-10">
            <button onclick="closeAuthModal()" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
            
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-lock text-primary text-2xl"></i>
                </div>
                <h3 class="text-2xl font-bold text-dark mb-2">Sign in Required</h3>
                <p class="text-gray-500">Please sign in to continue shopping</p>
            </div>
            
            <div class="space-y-3">
                <a href="{{ route('login') }}" class="block w-full bg-primary text-white py-3 rounded-xl font-bold text-center hover:bg-primary-dark transition">
                    <i class="fas fa-sign-in-alt mr-2"></i>Sign In
                </a>
                <a href="{{ route('register') }}" class="block w-full border-2 border-primary text-primary py-3 rounded-xl font-bold text-center hover:bg-primary hover:text-white transition">
                    <i class="fas fa-user-plus mr-2"></i>Create Account
                </a>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    
    <script>
        const isAuthenticated = @json(auth()->check());
        
        // Initialize Swipers
        document.addEventListener('DOMContentLoaded', function() {
            // Hero Swiper
            new Swiper('.hero-swiper', {
                loop: true,
                autoplay: { delay: 5000, disableOnInteraction: false },
                pagination: { el: '.swiper-pagination', clickable: true },
                effect: 'fade',
                fadeEffect: { crossFade: true }
            });
            
            // Flash Deals Swiper
            new Swiper('.flash-deals-swiper', {
                slidesPerView: 2,
                spaceBetween: 16,
                breakpoints: {
                    640: { slidesPerView: 3 },
                    768: { slidesPerView: 4 },
                    1024: { slidesPerView: 5 }
                }
            });
            
            // New Arrivals Swiper
            new Swiper('.new-arrivals-swiper', {
                slidesPerView: 2,
                spaceBetween: 16,
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                },
                breakpoints: {
                    640: { slidesPerView: 3 },
                    768: { slidesPerView: 4 },
                    1024: { slidesPerView: 5 }
                }
            });
            
            // Cart/Wishlist button handlers
            document.querySelectorAll('[data-quick-cart]').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    quickAddToCart(this.dataset.listingId, this);
                });
            });
            
            document.querySelectorAll('[data-quick-wishlist]').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    quickAddToWishlist(this.dataset.listingId, this);
                });
            });
            
            // Load counts
            if (isAuthenticated) {
                loadCartCount();
                loadWishlistCount();
            }
            
            // Flash sale timer
            startFlashTimer();
        });
        
        // Import Calculator
        function calculateImportCost() {
            const productValue = parseFloat(document.getElementById('productValue').value) || 0;
            const shippingCost = parseFloat(document.getElementById('shippingCost').value) || 0;
            const dutyRate = parseFloat(document.getElementById('dutyRate').value) || 10;
            const vatRate = parseFloat(document.getElementById('vatRate').value) || 18;
            
            const cif = productValue + shippingCost;
            const duty = cif * (dutyRate / 100);
            const vatBase = cif + duty;
            const vat = vatBase * (vatRate / 100);
            const total = cif + duty + vat;
            
            document.getElementById('resultProduct').textContent = '$' + productValue.toFixed(2);
            document.getElementById('resultShipping').textContent = '$' + shippingCost.toFixed(2);
            document.getElementById('resultDuty').textContent = '$' + duty.toFixed(2);
            document.getElementById('resultVat').textContent = '$' + vat.toFixed(2);
            document.getElementById('resultTotal').textContent = '$' + total.toFixed(2);
        }
        
        // Flash Sale Timer
        function startFlashTimer() {
            let hours = 12, minutes = 45, seconds = 30;
            
            setInterval(() => {
                seconds--;
                if (seconds < 0) { seconds = 59; minutes--; }
                if (minutes < 0) { minutes = 59; hours--; }
                if (hours < 0) { hours = 23; }
                
                const hoursEl = document.getElementById('hours');
                const minutesEl = document.getElementById('minutes');
                const secondsEl = document.getElementById('seconds');
                
                if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
                if (minutesEl) minutesEl.textContent = String(minutes).padStart(2, '0');
                if (secondsEl) secondsEl.textContent = String(seconds).padStart(2, '0');
            }, 1000);
        }
        
        // Auth Modal
        function showAuthModal() {
            document.getElementById('authModal').classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
        
        function closeAuthModal() {
            document.getElementById('authModal').classList.add('hidden');
            document.body.style.overflow = '';
        }
        
        // Toast Notification
        function showToast(message, type = 'info') {
            const colors = {
                success: 'bg-green-500',
                error: 'bg-red-500',
                info: 'bg-blue-500',
                warning: 'bg-amber-500'
            };
            
            const toast = document.createElement('div');
            toast.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-slide-in`;
            toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'}-circle mr-2"></i>${message}`;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
        
        // Quick Add to Cart
        async function quickAddToCart(listingId, button) {
            if (!isAuthenticated) {
                showAuthModal();
                return;
            }
            
            const originalHtml = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            button.disabled = true;
            
            try {
                const response = await fetch(`/buyer/cart/add/${listingId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ quantity: 1 })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    button.innerHTML = '<i class="fas fa-check"></i>';
                    showToast('Added to cart!', 'success');
                    if (data.cart_count) updateCartCount(data.cart_count);
                    setTimeout(() => {
                        button.innerHTML = originalHtml;
                        button.disabled = false;
                    }, 1500);
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                button.innerHTML = originalHtml;
                button.disabled = false;
                showToast(error.message || 'Failed to add to cart', 'error');
            }
        }
        
        // Quick Add to Wishlist
        async function quickAddToWishlist(listingId, button) {
            if (!isAuthenticated) {
                showAuthModal();
                return;
            }
            
            const icon = button.querySelector('i');
            
            try {
                const response = await fetch(`/buyer/wishlist/toggle/${listingId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    if (data.in_wishlist) {
                        icon.classList.remove('far');
                        icon.classList.add('fas', 'text-red-500');
                    } else {
                        icon.classList.remove('fas', 'text-red-500');
                        icon.classList.add('far');
                    }
                    showToast(data.message || 'Wishlist updated!', 'success');
                    if (data.wishlist_count !== undefined) updateWishlistCount(data.wishlist_count);
                }
            } catch (error) {
                showToast('Failed to update wishlist', 'error');
            }
        }
        
        // Update Counts
        function updateCartCount(count) {
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = count;
                el.classList.toggle('hidden', count === 0);
            });
        }
        
        function updateWishlistCount(count) {
            document.querySelectorAll('.wishlist-count').forEach(el => {
                el.textContent = count;
                el.classList.toggle('hidden', count === 0);
            });
        }
        
        async function loadCartCount() {
            try {
                const res = await fetch('/cart/count');
                const data = await res.json();
                if (data.cart_count) updateCartCount(data.cart_count);
            } catch (e) {}
        }
        
        async function loadWishlistCount() {
            try {
                const res = await fetch('/wishlist/count');
                const data = await res.json();
                if (data.count) updateWishlistCount(data.count);
            } catch (e) {}
        }
        
        // Quick View (placeholder)
        function quickView(productId) {
            // Implement quick view modal
            window.location.href = `/marketplace/${productId}`;
        }
    </script>
    
    <style>
        @keyframes slide-in {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .animate-slide-in { animation: slide-in 0.3s ease-out; }
        
        .swiper-button-prev, .swiper-button-next {
            background: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .swiper-button-prev::after, .swiper-button-next::after {
            font-size: 16px;
            color: #4f46e5;
            font-weight: bold;
        }
        
        .swiper-pagination-bullet-active {
            background: #4f46e5 !important;
        }
    </style>
</body>
</html>