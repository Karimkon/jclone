@extends('layouts.buyer')

@section('title', 'Shopping Cart - ' . config('app.name'))

@section('content')
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-8">Shopping Cart</h1>
    
    @if(session('success'))
    <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-6">
        <p class="text-green-700">{{ session('success') }}</p>
    </div>
    @endif
    
    @if(session('error'))
    <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
        <p class="text-red-700">{{ session('error') }}</p>
    </div>
    @endif
    
    @if($cart && !empty($cart->items))
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="p-6 border-b bg-gray-50">
                    <div class="flex justify-between items-center">
                        <h2 class="text-xl font-bold">Cart Items ({{ $cart->item_count }})</h2>
                        <form action="{{ route('buyer.cart.clear') }}" method="POST" onsubmit="return confirm('Are you sure you want to clear your cart?')">
                            @csrf
                            @method('POST')
                            <button type="submit" class="text-red-600 hover:text-red-800 text-sm font-medium">
                                <i class="fas fa-trash mr-1"></i> Clear Cart
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="divide-y">
                  @foreach($cart->getEnrichedItems() as $item)
@php
    // Properly extract variation data from the cart item structure
    $variant = $item['variant'] ?? null;
    $color = $item['color'] ?? null;
    $size = $item['size'] ?? null;
    $variantId = $item['variant_id'] ?? null;
    
    // Create unique item key
    $itemKey = $item['listing_id'] . '_' . ($variantId ?? 'base') . '_' . ($color ?? '') . '_' . ($size ?? '');
    
    // Get correct attributes from variant or direct item
    $variantAttributes = $variant['attributes'] ?? [];
    $displayColor = $color ?? $variantAttributes['color'] ?? $variantAttributes['Color'] ?? null;
    $displaySize = $size ?? $variantAttributes['size'] ?? $variantAttributes['Size'] ?? null;
    
    // Add missing variables
    $stock = $item['stock'] ?? ($variant['stock'] ?? ($item['listing']['stock'] ?? 0));
    $unitPrice = $item['unit_price'] ?? ($variant['display_price'] ?? ($variant['price'] ?? 0));
@endphp

<div class="p-6 cart-item" data-listing-id="{{ $item['listing_id'] }}" data-item-key="{{ $itemKey }}">
    <div class="flex space-x-4">
        <!-- Product Image -->
        <div class="w-24 h-24 flex-shrink-0">
            @if($item['image'])
            <img src="{{ $item['image'] }}" alt="{{ $item['title'] }}" 
                 class="w-full h-full object-cover rounded-lg">
            @elseif(isset($item['listing']['images'][0]))
            <img src="{{ asset('storage/' . $item['listing']['images'][0]['path']) }}" 
                 alt="{{ $item['title'] }}" 
                 class="w-full h-full object-cover rounded-lg">
            @else
            <div class="w-full h-full bg-gray-200 rounded-lg flex items-center justify-center">
                <i class="fas fa-image text-gray-400 text-2xl"></i>
            </div>
            @endif
        </div>
        
        <!-- Product Details -->
        <div class="flex-1">
            <div class="flex justify-between">
                <div>
                    <h3 class="font-bold text-lg mb-1">{{ $item['title'] }}</h3>
                    <p class="text-sm text-gray-600 mb-2">
                        <i class="fas fa-store mr-1"></i> {{ $item['vendor_name'] ?? ($item['listing']['vendor']['business_name'] ?? 'Vendor') }}
                    </p>
                    
                    <!-- Display Variations if they exist -->
                    @if($variant || $displayColor || $displaySize)
                    <div class="mb-2">
                        <div class="text-sm text-gray-700 space-y-1">
                            @if($displayColor)
                            <div class="flex items-center">
                                <span class="font-medium w-16">Color:</span>
                                <span class="px-2 py-1 bg-gray-100 rounded text-sm">{{ $displayColor }}</span>
                            </div>
                            @endif
                            
                            @if($displaySize)
                            <div class="flex items-center">
                                <span class="font-medium w-16">Size:</span>
                                <span class="px-2 py-1 bg-gray-100 rounded text-sm">{{ $displaySize }}</span>
                            </div>
                            @endif
                            
                            @if($variant && isset($variant['sku']))
                            <div class="flex items-center">
                                <span class="font-medium w-16">SKU:</span>
                                <span class="text-gray-600 text-sm">{{ $variant['sku'] }}</span>
                            </div>
                            @endif
                        </div>
                    </div>
                    @endif
                    
                    <div class="flex items-center space-x-4 text-sm text-gray-500">
                        @if(isset($item['origin']))
                        <span class="px-2 py-1 bg-{{ $item['origin'] == 'imported' ? 'blue' : 'green' }}-100 text-{{ $item['origin'] == 'imported' ? 'blue' : 'green' }}-800 rounded text-xs">
                            <i class="fas fa-{{ $item['origin'] == 'imported' ? 'plane' : 'home' }} mr-1"></i>
                            {{ ucfirst($item['origin']) }}
                        </span>
                        @endif
                        @if(isset($item['weight_kg']))
                        <span><i class="fas fa-weight-hanging mr-1"></i> {{ $item['weight_kg'] }}kg</span>
                        @endif
                    </div>
                </div>
                
                <!-- Remove Button -->
                <button onclick="removeFromCart({{ $item['listing_id'] }}, '{{ $variantId }}', '{{ $color }}', '{{ $size }}')" 
                        class="text-red-600 hover:text-red-800 h-8">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <!-- Quantity and Price -->
            <div class="mt-4 flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <span class="text-sm text-gray-600">Quantity:</span>
                    <div class="flex items-center border border-gray-300 rounded-lg">
                        <button type="button" 
                                onclick="updateQuantity({{ $item['listing_id'] }}, {{ $item['quantity'] - 1 }}, '{{ $variantId }}', '{{ $color }}', '{{ $size }}')"
                                class="px-3 py-1 hover:bg-gray-100"
                                {{ $item['quantity'] <= 1 ? 'disabled' : '' }}>
                            <i class="fas fa-minus text-sm"></i>
                        </button>
                        <input type="number" 
                               id="qty-{{ $itemKey }}"
                               value="{{ $item['quantity'] }}" 
                               min="1" 
                               max="{{ $stock }}"
                               class="w-16 text-center border-0 focus:ring-0 py-1"
                               onchange="updateQuantity({{ $item['listing_id'] }}, this.value, '{{ $variantId }}', '{{ $color }}', '{{ $size }}')">
                        <button type="button" 
                                onclick="updateQuantity({{ $item['listing_id'] }}, {{ $item['quantity'] + 1 }}, '{{ $variantId }}', '{{ $color }}', '{{ $size }}')"
                                class="px-3 py-1 hover:bg-gray-100"
                                {{ $item['quantity'] >= $stock ? 'disabled' : '' }}>
                            <i class="fas fa-plus text-sm"></i>
                        </button>
                    </div>
                    @if($stock)
                    <span class="text-xs text-gray-500">({{ $stock }} available)</span>
                    @endif
                </div>
                
                <div class="text-right">
                    <div class="text-sm text-gray-600">UGX {{ number_format($unitPrice, 2) }} each</div>
                    <div class="text-lg font-bold text-primary item-total" id="total-{{ $itemKey }}">
                        UGX {{ number_format($item['total'] ?? ($unitPrice * $item['quantity']), 2) }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endforeach
                    
                    
                </div>
            </div>
        </div>
        
        <!-- Order Summary -->
<div class="lg:col-span-1">
    <div class="bg-white rounded-lg shadow p-6 sticky top-4">
        <h2 class="text-xl font-bold mb-4">Order Summary</h2>
        
        <div class="space-y-3 mb-6">
            <div class="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span id="cart-subtotal">UGX {{ number_format($cart->subtotal, 2) }}</span>
            </div>
            <div class="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span id="cart-shipping">UGX {{ number_format($cart->shipping, 2) }}</span>
            </div>
            <div class="flex justify-between text-gray-600">
                <span>Tax (18%)</span>
                <span id="cart-tax">UGX {{ number_format($cart->tax, 2) }}</span>
            </div>
            <div class="pt-3 border-t">
                <div class="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span class="text-primary" id="cart-total">UGX {{ number_format($cart->total, 2) }}</span>
                </div>
            </div>
        </div>
        
        <a href="{{ route('buyer.orders.checkout') }}" 
           class="block w-full text-white text-center py-3 rounded-lg font-bold transition mb-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
           style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%) !important;">
            <i class="fas fa-lock mr-2"></i> Proceed to Checkout
        </a>
        
        <a href="{{ route('marketplace.index') }}" 
           class="block w-full text-center py-3 border-2 border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition font-semibold">
            <i class="fas fa-shopping-bag mr-2"></i> Continue Shopping
        </a>
        
        <div class="mt-6 pt-6 border-t">
            <div class="flex items-start space-x-2 text-sm text-gray-600">
                <i class="fas fa-shield-alt text-green-600 mt-1"></i>
                <div>
                    <p class="font-medium text-gray-800">Secure Checkout</p>
                    <p>Your payment is protected by escrow</p>
                </div>
            </div>
        </div>
    </div>
</div>
    
    @else
    <!-- Empty Cart -->
    <div class="bg-white rounded-lg shadow p-12 text-center">
        <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
            <i class="fas fa-shopping-cart text-gray-400 text-4xl"></i>
        </div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Your cart is empty</h2>
        <p class="text-gray-600 mb-6">Add some products to get started!</p>
        <a href="{{ route('marketplace.index') }}" 
           class="inline-flex items-center px-6 py-3 bg-primary text-white rounded-lg font-semibold hover:bg-indigo-700 transition">
            <i class="fas fa-shopping-bag mr-2"></i> Start Shopping
        </a>
    </div>
    @endif
</div>

<script>
// Update quantity with variation support
function updateQuantity(listingId, quantity, variantId = null, color = null, size = null) {
    quantity = parseInt(quantity);
    if (quantity < 1) return;
    
    const itemKey = `${listingId}_${variantId || 'base'}_${color || ''}_${size || ''}`;
    const qtyInput = document.getElementById(`qty-${itemKey}`);
    if (qtyInput) {
        qtyInput.value = quantity;
    }
    
    fetch(`/buyer/cart/update/${listingId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        },
        body: JSON.stringify({ 
            quantity: quantity,
            variant_id: variantId,
            color: color,
            size: size
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update item total
            const itemTotalElement = document.getElementById(`total-${itemKey}`);
            if (itemTotalElement) {
                itemTotalElement.textContent = 'UGX ' + data.item_total.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }
            
            // Update cart summary
            updateCartSummary(data);
            
            // Update stock availability
            if (data.stock !== undefined && qtyInput) {
                const plusButton = qtyInput.nextElementSibling;
                if (plusButton) {
                    plusButton.disabled = quantity >= data.stock;
                }
                const minusButton = qtyInput.previousElementSibling;
                if (minusButton) {
                    minusButton.disabled = quantity <= 1;
                }
            }
            
            showToast(data.message, 'success');
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Failed to update quantity', 'error');
    });
}

// Remove from cart with variation support
function removeFromCart(listingId, variantId = null, color = null, size = null) {
    if (!confirm('Remove this item from cart?')) return;
    
    const data = {
        variant_id: variantId,
        color: color,
        size: size
    };
    
    fetch(`/buyer/cart/remove/${listingId}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Remove item from DOM
            const itemKey = `${listingId}_${variantId || 'base'}_${color || ''}_${size || ''}`;
            const item = document.querySelector(`.cart-item[data-item-key="${itemKey}"]`);
            if (item) {
                item.remove();
            }
            
            // Update cart summary
            updateCartSummary(data);
            
            // Update cart count in navbar
            if (data.cart_count !== undefined) {
                updateCartCount(data.cart_count);
            }
            
            // If cart is now empty, reload page
            if (data.cart_count === 0) {
                setTimeout(() => {
                    location.reload();
                }, 1000);
            }
            
            showToast(data.message, 'success');
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Failed to remove item', 'error');
    });
}

// Update cart summary
function updateCartSummary(data) {
    if (data.subtotal !== undefined) {
        const subtotalElement = document.getElementById('cart-subtotal');
        if (subtotalElement) {
            subtotalElement.textContent = 'UGX ' + data.subtotal.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }
    
    if (data.shipping !== undefined) {
        const shippingElement = document.getElementById('cart-shipping');
        if (shippingElement) {
            shippingElement.textContent = 'UGX ' + data.shipping.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }
    
    if (data.tax !== undefined) {
        const taxElement = document.getElementById('cart-tax');
        if (taxElement) {
            taxElement.textContent = 'UGX ' + data.tax.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }
    
    if (data.cart_total !== undefined) {
        const totalElement = document.getElementById('cart-total');
        if (totalElement) {
            totalElement.textContent = 'UGX ' + data.cart_total.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }
}

// Update cart count in navbar
function updateCartCount(count) {
    document.querySelectorAll('.cart-count').forEach(element => {
        element.textContent = count;
        if (count > 0) {
            element.classList.remove('hidden');
        } else {
            element.classList.add('hidden');
        }
    });
}

// Show toast notification
function showToast(message, type = 'info') {
    // Remove existing toasts
    const existingToasts = document.querySelectorAll('.custom-toast');
    existingToasts.forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = 'custom-toast fixed top-4 right-4 z-50 transform transition-all duration-300';
    
    const typeStyles = {
        success: 'bg-green-500 text-white',
        error: 'bg-red-500 text-white',
        warning: 'bg-yellow-500 text-white',
        info: 'bg-blue-500 text-white'
    };
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    toast.className += ` ${typeStyles[type] || typeStyles.info} px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 animate-slideIn`;
    
    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span class="font-medium">${message}</span>
        <button class="ml-2 hover:opacity-80" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }
    }, 4000);
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + A to select all inputs in the focused quantity field
    if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
        const activeElement = document.activeElement;
        if (activeElement && activeElement.type === 'number' && activeElement.id.startsWith('qty-')) {
            e.preventDefault();
            activeElement.select();
        }
    }
    
    // Arrow keys for quantity adjustment
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        const activeElement = document.activeElement;
        if (activeElement && activeElement.type === 'number' && activeElement.id.startsWith('qty-')) {
            e.preventDefault();
            
            // Find the parent cart item to get variation details
            const cartItem = activeElement.closest('.cart-item');
            if (cartItem) {
                const listingId = cartItem.dataset.listingId;
                const itemKey = cartItem.dataset.itemKey;
                const parts = itemKey.split('_');
                const variantId = parts[1] !== 'base' ? parts[1] : null;
                const color = parts[2] || null;
                const size = parts[3] || null;
                
                let currentQty = parseInt(activeElement.value);
                let newQty = e.key === 'ArrowUp' ? currentQty + 1 : currentQty - 1;
                
                if (newQty >= 1) {
                    updateQuantity(listingId, newQty, variantId, color, size);
                }
            }
        }
    }
});

// Add some CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100%);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    .animate-slideIn {
        animation: slideIn 0.3s ease-out;
    }
    
    .cart-item {
        transition: all 0.3s ease;
    }
    
    .cart-item:hover {
        background-color: #f9fafb;
    }
    
    .custom-toast {
        min-width: 300px;
    }
`;
document.head.appendChild(style);
</script>
@endsection