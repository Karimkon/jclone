<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class PesapalService
{
    protected $baseUrl;
    protected $consumerKey;
    protected $consumerSecret;
    protected $notificationId;

    public function __construct()
    {
        $this->baseUrl = config('services.pesapal.base_url', 'https://pay.pesapal.com/v3');
        $this->consumerKey = config('services.pesapal.consumer_key');
        $this->consumerSecret = config('services.pesapal.consumer_secret');
        $this->notificationId = config('services.pesapal.notification_id');
    }

    /**
     * Get access token from Pesapal (with caching)
     */
    public function getAccessToken(): ?string
    {
        // Cache token for 4 minutes (expires at 5)
        return Cache::remember('pesapal_access_token', 240, function () {
            try {
                $response = Http::withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ])->post($this->baseUrl . '/api/Auth/RequestToken', [
                    'consumer_key' => $this->consumerKey,
                    'consumer_secret' => $this->consumerSecret,
                ]);

                if ($response->successful()) {
                    $data = $response->json();
                    Log::info('PesaPal token obtained successfully');
                    return $data['token'] ?? null;
                }

                Log::error('PesaPal Auth Failed: ' . $response->body());
                return null;
            } catch (\Exception $e) {
                Log::error('PesaPal Auth Exception: ' . $e->getMessage());
                return null;
            }
        });
    }

    /**
     * Register IPN (Instant Payment Notification) URL
     */
    public function registerIPN(string $url, string $type = 'GET'): ?array
    {
        $token = $this->getAccessToken();
        if (!$token) {
            throw new \Exception('Failed to get PesaPal access token');
        }

        try {
            $response = Http::withToken($token)
                ->withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json'
                ])
                ->post($this->baseUrl . '/api/URLSetup/RegisterIPN', [
                    'url' => $url,
                    'ipn_notification_type' => $type,
                ]);

            if ($response->successful()) {
                $data = $response->json();
                Log::info('PesaPal IPN registered:', $data);
                return $data;
            }

            Log::error('PesaPal IPN Registration Failed: ' . $response->body());
            return null;
        } catch (\Exception $e) {
            Log::error('PesaPal IPN Registration Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Submit order to Pesapal for Mobile Money payment
     */
    public function submitOrder(array $orderData): array
    {
        $token = $this->getAccessToken();
        if (!$token) {
            throw new \Exception('Failed to get PesaPal access token');
        }

        // Ensure notification_id is set
        if (!isset($orderData['notification_id'])) {
            $orderData['notification_id'] = $this->notificationId;
        }

        try {
            $response = Http::withToken($token)
                ->withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json'
                ])
                ->post($this->baseUrl . '/api/Transactions/SubmitOrderRequest', $orderData);

            Log::info('PesaPal submitOrder request:', $orderData);
            Log::info('PesaPal submitOrder response:', ['body' => $response->body()]);

            if ($response->successful()) {
                return $response->json();
            }

            Log::error('PesaPal Order Failed: ' . $response->body());
            throw new \Exception('PesaPal order submission failed: ' . $response->body());
        } catch (\Exception $e) {
            Log::error('PesaPal Order Exception: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Get transaction status from Pesapal
     */
    public function getTransactionStatus(string $orderTrackingId): ?array
    {
        $token = $this->getAccessToken();
        if (!$token) {
            throw new \Exception('Failed to get PesaPal access token');
        }

        try {
            $response = Http::withToken($token)
                ->withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json'
                ])
                ->get($this->baseUrl . '/api/Transactions/GetTransactionStatus', [
                    'orderTrackingId' => $orderTrackingId
                ]);

            if ($response->successful()) {
                return $response->json();
            }

            Log::error('PesaPal Status Check Failed: ' . $response->body());
            return null;
        } catch (\Exception $e) {
            Log::error('PesaPal Status Exception: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Check if payment is successful based on status code
     * Status codes: 0 = Invalid, 1 = Completed, 2 = Failed, 3 = Reversed
     */
    public function isPaymentSuccessful(array $status): bool
    {
        return isset($status['status_code']) && $status['status_code'] == 1;
    }

    /**
     * Get payment status description
     */
    public function getStatusDescription(int $statusCode): string
    {
        return match($statusCode) {
            0 => 'Invalid',
            1 => 'Completed',
            2 => 'Failed',
            3 => 'Reversed',
            default => 'Unknown'
        };
    }
}
