protected $except = [
    'webhooks/*',
     'payment/pesapal/callback',  // Add this if needed
];