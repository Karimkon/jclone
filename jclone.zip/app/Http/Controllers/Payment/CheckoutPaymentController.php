<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Escrow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CheckoutPaymentController extends Controller
{
    protected $pesapalService;

    public function __construct()
    {
        // Initialize PesaPal service
        $this->pesapalService = app(\App\Services\PesapalService::class);
    }

    /**
     * Show payment options page
     */
    public function showPaymentOptions(Order $order)
    {
        // Ensure user owns this order
        if ($order->buyer_id !== auth()->id()) {
            abort(403, 'Unauthorized');
        }

        // Ensure order is pending payment
        if (!in_array($order->status, ['payment_pending', 'pending'])) {
            return redirect()->route('buyer.orders.show', $order)
                ->with('error', 'This order has already been processed.');
        }

        return view('buyer.orders.payment', [
            'order' => $order->load(['items.listing.images', 'vendorProfile']),
        ]);
    }

    /**
     * Initialize PesaPal payment (Mobile Money)
     */
    public function initializePesapalPayment(Request $request, Order $order)
    {
        $request->validate([
            'mobile_money_provider' => 'required|in:mtn,airtel',
            'phone_number' => 'required|regex:/^[0-9]{10,15}$/',
        ]);

        // Verify ownership and status
        if ($order->buyer_id !== auth()->id()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        if (!in_array($order->status, ['payment_pending', 'pending'])) {
            return response()->json(['success' => false, 'message' => 'Order already processed'], 400);
        }

        $txRef = 'JCLONE-' . time() . '-' . $order->id;

        try {
            // Prepare PesaPal order data
            $orderData = [
                'id' => $txRef,
                'currency' => 'UGX', // Changed to UGX
                'amount' => $order->total,
                'description' => "Payment for Order #{$order->order_number}",
                'callback_url' => route('payment.pesapal.callback'),
                'notification_id' => config('services.pesapal.notification_id'),
                'billing_address' => [
                    'email_address' => $order->buyer->email ?? 'buyer@jclone.com',
                    'phone_number' => $request->phone_number,
                    'country_code' => 'UG',
                    'first_name' => explode(' ', $order->buyer->name)[0] ?? 'Buyer',
                    'middle_name' => '',
                    'last_name' => explode(' ', $order->buyer->name)[1] ?? '',
                ],
                'payment_method' => strtoupper($request->mobile_money_provider),
            ];

            // Submit order to PesaPal
            $result = $this->pesapalService->submitOrder($orderData);

            if (isset($result['redirect_url'])) {
                // Create pending payment record
                $payment = Payment::create([
                    'order_id' => $order->id,
                    'provider' => 'pesapal',
                    'provider_payment_id' => $txRef,
                    'amount' => $order->total,
                    'status' => 'pending',
                    'meta' => [
                        'payment_method' => 'mobile_money',
                        'mobile_provider' => $request->mobile_money_provider,
                        'phone_number' => $request->phone_number,
                        'order_tracking_id' => $result['order_tracking_id'] ?? null,
                        'initiated_at' => now()->toDateTimeString(),
                        'payment_url' => $result['redirect_url'],
                    ]
                ]);

                // Update order meta
                $order->update([
                    'meta' => array_merge($order->meta ?? [], [
                        'payment_reference' => $txRef,
                        'mobile_payment_details' => [
                            'provider' => $request->mobile_money_provider,
                            'phone' => $request->phone_number,
                        ]
                    ])
                ]);

                return response()->json([
                    'success' => true,
                    'payment_url' => $result['redirect_url'],
                    'tx_ref' => $txRef,
                    'order_tracking_id' => $result['order_tracking_id'] ?? null,
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => $result['error']['message'] ?? 'Failed to initialize mobile money payment'
            ], 500);

        } catch (\Exception $e) {
            Log::error('PesaPal payment initialization failed: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Payment initialization failed. Please try again.'
            ], 500);
        }
    }

    /**
     * PesaPal callback handler
     */
    public function pesapalCallback(Request $request)
    {
        $orderTrackingId = $request->query('OrderTrackingId');
        $orderMerchantReference = $request->query('OrderMerchantReference');

        Log::info('PesaPal callback received:', [
            'orderTrackingId' => $orderTrackingId,
            'orderMerchantReference' => $orderMerchantReference,
            'all_params' => $request->all()
        ]);

        if (!$orderTrackingId) {
            Log::error('PesaPal callback missing OrderTrackingId');
            return redirect()->route('buyer.orders.index')
                ->with('error', 'Invalid payment response');
        }

        try {
            // Get transaction status from PesaPal
            $status = $this->pesapalService->getTransactionStatus($orderTrackingId);

            Log::info('PesaPal transaction status:', $status);

            if ($status && $this->pesapalService->isPaymentSuccessful($status)) {
                return $this->processSuccessfulPayment($orderMerchantReference, $status);
            }

            $statusDesc = $this->pesapalService->getStatusDescription($status['status_code'] ?? 0);
            Log::warning('PesaPal payment not successful:', ['status' => $statusDesc]);
            
            return $this->handlePaymentFailed($orderMerchantReference, $statusDesc);

        } catch (\Exception $e) {
            Log::error('PesaPal callback error: ' . $e->getMessage());
            return redirect()->route('buyer.orders.index')
                ->with('error', 'Payment verification failed. Please contact support.');
        }
    }

    /**
     * Process successful payment
     */
    private function processSuccessfulPayment(string $txRef, array $providerData)
    {
        $payment = Payment::where('provider_payment_id', $txRef)
            ->where('provider', 'pesapal')
            ->first();

        if (!$payment) {
            Log::error("Payment not found for PesaPal: {$txRef}");
            return redirect()->route('buyer.orders.index')
                ->with('error', 'Payment record not found');
        }

        if ($payment->status === 'completed') {
            return redirect()->route('buyer.orders.show', $payment->order)
                ->with('success', 'Payment already completed!');
        }

        try {
            DB::beginTransaction();

            // Update payment status
            $payment->update([
                'status' => 'completed',
                'meta' => array_merge($payment->meta ?? [], [
                    'provider_response' => $providerData,
                    'completed_at' => now()->toDateTimeString(),
                    'payment_confirmation' => $providerData['payment_confirmation'] ?? null,
                ])
            ]);

            $order = $payment->order;

            // Update order status to paid
            $order->update(['status' => 'paid']);

            // Create escrow for buyer protection
            Escrow::create([
                'order_id' => $order->id,
                'amount' => $order->total,
                'status' => 'held',
                'release_at' => now()->addDays(7),
                'meta' => [
                    'release_condition' => 'buyer_confirmation_or_auto',
                    'auto_release_days' => 7,
                    'payment_provider' => 'pesapal',
                    'payment_reference' => $txRef,
                ]
            ]);

            // Notify vendor
            \App\Models\NotificationQueue::create([
                'user_id' => $order->vendorProfile->user_id,
                'type' => 'order_paid',
                'title' => 'New Paid Order!',
                'message' => "Order #{$order->order_number} has been paid. Amount: UGX " . number_format($order->total, 0),
                'meta' => ['order_id' => $order->id],
                'status' => 'pending',
            ]);

            // Notify buyer
            \App\Models\NotificationQueue::create([
                'user_id' => $order->buyer_id,
                'type' => 'payment_successful',
                'title' => 'Payment Successful',
                'message' => "Your payment for order #{$order->order_number} was successful. The vendor will process your order soon.",
                'meta' => ['order_id' => $order->id],
                'status' => 'pending',
            ]);

            DB::commit();

            Log::info("PesaPal payment completed successfully", [
                'payment_id' => $payment->id,
                'order_id' => $order->id,
                'amount' => $payment->amount,
            ]);

            return redirect()->route('buyer.orders.show', $order)
                ->with('success', 'Payment completed successfully! Your order is being processed.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Payment completion error: ' . $e->getMessage());
            return redirect()->route('buyer.orders.index')
                ->with('error', 'Payment recorded but order update failed. Please contact support.');
        }
    }

    /**
     * Handle payment failure
     */
    private function handlePaymentFailed(string $txRef, string $reason)
    {
        $payment = Payment::where('provider_payment_id', $txRef)
            ->where('provider', 'pesapal')
            ->first();

        if ($payment) {
            $payment->update([
                'status' => 'failed',
                'meta' => array_merge($payment->meta ?? [], [
                    'failure_reason' => $reason,
                    'failed_at' => now()->toDateTimeString(),
                ])
            ]);

            return redirect()->route('buyer.orders.show', $payment->order)
                ->with('error', "Payment failed: {$reason}. Please try again.");
        }

        return redirect()->route('buyer.orders.index')
            ->with('error', "Payment failed: {$reason}");
    }

    /**
     * Check PesaPal payment status
     */
    public function checkPaymentStatus(Request $request, Order $order)
    {
        if ($order->buyer_id !== auth()->id()) {
            abort(403);
        }

        $payment = $order->payments()
            ->where('provider', 'pesapal')
            ->where('status', 'pending')
            ->first();

        if (!$payment || !isset($payment->meta['order_tracking_id'])) {
            return response()->json(['success' => false, 'message' => 'No pending PesaPal payment found']);
        }

        try {
            $status = $this->pesapalService->getTransactionStatus($payment->meta['order_tracking_id']);

            if ($status && $this->pesapalService->isPaymentSuccessful($status)) {
                // Payment is successful, process it
                $this->processSuccessfulPayment($payment->provider_payment_id, $status);
                
                return response()->json([
                    'success' => true,
                    'status' => 'completed',
                    'message' => 'Payment completed successfully!'
                ]);
            }

            return response()->json([
                'success' => true,
                'status' => $status['status_code'] ?? 'pending',
                'message' => 'Payment is still processing'
            ]);

        } catch (\Exception $e) {
            Log::error('Check payment status error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Failed to check payment status']);
        }
    }
}