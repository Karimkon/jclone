<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ListingImageController extends Controller
{
    //
}
