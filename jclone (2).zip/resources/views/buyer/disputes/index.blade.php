@extends('layouts.buyer')

@section('title', 'Disputes - ' . config('app.name'))

@endsection